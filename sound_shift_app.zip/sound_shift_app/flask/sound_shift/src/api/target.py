from flask import Blueprint, jsonify, abort, request
from ..models import Target, User, db

bp = Blueprint("target_music_app_data", __name__, url_prefix="/target_music_app_data")


@bp.route("", methods=["GET"])  # decorator takes path and list of HTTP verbs
def index():
    target_music = Target.query.all()  # ORM performs SELECT query
    result = []
    for tm in target_music:
        result.append(tm.serialize())  # build list of Target music as dictionaries
    return jsonify(result)  # return JSON response


@bp.route("/<int:id>", methods=["GET"])
def show(id: int):
    tm = Target.query.get_or_404(id, "Target music not found")
    return jsonify(tm.serialize())


@bp.route("/upload_music", methods=["POST"])
def upload_music():
    # Check if required fields are present in the request
    if (
        "user_id" not in request.json
        or "target_track_id" not in request.json
        or "target_playlist_id" not in request.json
    ):
        return abort(400, "Missing required fields")

    user_id = request.json["user_id"]
    target_track_id = request.json["target_track_id"]
    target_playlist_id = request.json["target_playlist_id"]

    # Check if the user with the specified user_id exists
    user = User.query.get_or_404(user_id, "User not found")

    # Create a new target music entry
    target_music = Target(
        user_id=user.id,
        target_track_id=target_track_id,
        target_playlist_id=target_playlist_id,
    )

    try:
        db.session.add(target_music)
        db.session.commit()
        return jsonify(target_music.serialize())
    except Exception as e:
        db.session.rollback()
        return abort(500, f"Failed to upload music: {str(e)}")


@bp.route("/<int:id>", methods=["DELETE"])
def delete(id: int):
    tm = Target.query.get_or_404(id, "Target music not found")
    try:
        db.session.delete(tm)  # prepare DELETE statement
        db.session.commit()  # execute DELETE statement
        return jsonify(True)
    except:
        # something went wrong :(
        return jsonify(False)


@bp.route("/<int:id>/liked_musics", methods=["GET"])
def liked_music(id: int):
    user = User.query.get_or_404(id)
    result = []
    for music_item in user.liked_music:
        result.append(music_item.serialize())
    return jsonify(result)


@bp.route("/<int:id>/liking_users", methods=["GET"])
def liking_users(user_id: int):
    tm = Target.query.get_or_404(id)
    result = []
    for user in tm.liking_users:
        result.append(user.serialize())
    return jsonify(result)
