# Sound Shift - Music Transferring App

## Description

Sound Shift allows users to easily transfer and share their favorite music tracks with others. Whether you want to send a song to a friend or collaborate on playlists, this app has you covered.

## API Reference

### Endpoints

| Method   | Endpoint                        | Parameters                                        | Description                            |
| -------- | ------------------------------- | ------------------------------------------------- | -------------------------------------- |
| GET      | `/api/music`                    | None                                              | Retrieve a list of available music tracks. |
| POST     | `/api/upload_music`             | `user_id` (int), `music_title` (string), `music_file` (file) | Upload music to the app.             |
| GET      | `/api/user/<user_id>/liked_music` | None 

### Retrospective

#### Project Design Evolution

The project's design evolved significantly over time. Initially, it started as a simple file-sharing app but grew to include music management features.

#### ORM vs. Raw SQL

I chose to use an ORM (Object-Relational Mapping) for database interactions. This decision was made to simplify database operations, enhance code maintainability, and reduce the risk of SQL injection vulnerabilities.

#### Future Improvements

- Implement a recommendation system based on user preferences.
- Enhance playlist management with collaborative features.
- Add support for additional audio formats.
