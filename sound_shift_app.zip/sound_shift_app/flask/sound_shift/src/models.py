import datetime
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class User(db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(128), unique=True, nullable=False)
    password = db.Column(db.String(128), nullable=False)
    email = db.Column(db.String(128), nullable=False)
    source_music_app_data = db.relationship(
        "Source", backref="source_music_app_data", cascade="all,delete"
    )
    target_music_app_data = db.relationship(
        "Target", backref="target_music_app_data", cascade="all,delete"
    )

    def __init__(self, username: str, email: str, password: str):
        self.username = username
        self.email = email
        self.password = password

    def serialize(self):
        return {"id": self.id, "username": self.username, "email": self.email}


mappings_table = db.Table(
    "mappings",
    db.Column("user_id", db.Integer, db.ForeignKey("users.id"), primary_key=True),
    db.Column(
        "source_track_id",
        db.Integer,
        db.ForeignKey("source_music_app_data.id"),
        primary_key=False,
    ),
    db.Column(
        "target_track_id",
        db.Integer,
        db.ForeignKey("target_music_app_data.id"),
        primary_key=False,
    ),
    db.Column(
        "source_track_id",
        db.Integer,
        db.ForeignKey("source_music_app_data.id"),
        primary_key=False,
    ),
    db.Column(
        "target_track_id",
        db.Integer,
        db.ForeignKey("target_music_app_data.id"),
        primary_key=False,
    ),
    db.Column(
        "transfer_date", db.DateTime, default=datetime.datetime.utcnow, nullable=False
    ),
)


class Source(db.Model):
    __tablename__ = "source_music_app_data"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    source_track_id = db.Column(db.Integer, nullable=False)
    source_playlist_id = db.Column(db.Integer, nullable=False)
    users = db.relationship(
        "User",
        secondary=mappings_table,
        lazy="subquery",
        backref="source_music_app_data",
        cascade="all,delete",
    )

    def __init__(self, user_id: int, source_track_id: int, source_playlist_id: int):
        self.user_id = user_id
        self.source_track_id = source_track_id
        self.source_playlist_id = source_playlist_id

    def serialize(self):
        return {
            "id": self.id,
            "source_track_id": self.source_track_id,
            "source_playlist_id": self.source_playlist_id,
            "user_id": self.user_id,
        }


class Target(db.Model):
    __tablename__ = "target_music_app_data"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    target_track_id = db.Column(db.Integer, nullable=False)
    target_playlist_id = db.Column(db.Integer, nullable=False)
    users = db.relationship(
        "User",
        secondary=mappings_table,
        lazy="subquery",
        backref="target_music_app_data",
        cascade="all,delete",
    )

    def __init__(self, user_id: int, target_track_id: int, target_playlist_id: int):
        self.user_id = user_id
        self.target_track_id = target_track_id
        self.target_playlist_id = target_playlist_id

    def serialize(self):
        return {
            "id": self.id,
            "target_track_id": self.target_track_id,
            "target_playlist_id": self.target_playlist_id,
            "user_id": self.user_id,
        }
