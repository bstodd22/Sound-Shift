"""target music

Revision ID: d0357f6829c3
Revises: 0ef1b2ae5856
Create Date: 2023-09-22 19:58:11.758310

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "d0357f6829c3"
down_revision = "0ef1b2ae5856"
branch_labels = None
depends_on = None


def upgrade():
    op.execute(
        """
    CREATE TABLE target_music(
            id SERIAL PRIMARY KEY,
            user_id INT NOT NULL,
            target_track_id INT NOT NULL,
            target_playlist_id INT NOT NULL,
            track_title TEXT NOT NULL,
            artist TEXT,
            album TEXT
        );
    """
    )


def downgrade():
    op.execute(
        """
        DROP TABLE target_music;
        """
    )
