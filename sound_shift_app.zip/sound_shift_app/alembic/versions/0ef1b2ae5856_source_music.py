"""source music

Revision ID: 0ef1b2ae5856
Revises: 
Create Date: 2023-09-22 19:57:57.913306

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "0ef1b2ae5856"
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    op.execute(
        """
        CREATE TABLE source_music(
            id SERIAL PRIMARY KEY,
            user_id INT NOT NULL,
            source_track_id INT NOT NULL,
            source_playlist_id INT NOT NULL,
            track_title TEXT NOT NULL,
            artist TEXT,
            album TEXT
        );
        """
    )


def downgrade():
    op.execute(
        """
        DROP TABLE source_music;
        """
    )
