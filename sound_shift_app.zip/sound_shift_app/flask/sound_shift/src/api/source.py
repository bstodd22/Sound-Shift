from flask import Blueprint, jsonify, abort, request
from ..models import Source, User, db

bp = Blueprint("source_music_app_data", __name__, url_prefix="/source_music_app_data")


@bp.route("", methods=["GET"])  # decorator takes path and list of HTTP verbs
def index():
    source_music = Source.query.all()  # ORM performs SELECT query
    result = []
    for sm in source_music:
        result.append(sm.serialize())  # build list of Tweets as dictionaries
    return jsonify(result)  # return JSON response


@bp.route("/<int:id>", methods=["GET"])
def show(id: int):
    sm = Source.query.get_or_404(id, "Tweet not found")
    return jsonify(sm.serialize())


@bp.route("", methods=["POST"])
def upload_music():
    # req body must contain user_id and content
    if (
        "user_id" not in request.json
        or "source_track_id" not in request.json
        or "source_playlist_id" not in request.json
    ):
        return abort(400)
    # user with id of user_id must exist
    User.query.get_or_404(request.json["user_id"], "User not found")
    # construct Tweet
    sm = Source(
        user_id=request.json["user_id"],
        source_track_id=request.json["source_track_id"],
        source_playlist_id=request.json["source_playlist_id"],
    )
    db.session.add(sm)  # prepare CREATE statement
    db.session.commit()  # execute CREATE statement
    return jsonify(sm.serialize())


@bp.route("/<int:id>", methods=["DELETE"])
def delete(id: int):
    sm = Source.query.get_or_404(id, "Source music not found")
    try:
        db.session.delete(sm)  # prepare DELETE statement
        db.session.commit()  # execute DELETE statement
        return jsonify(True)
    except:
        # something went wrong :(
        return jsonify(False)


@bp.route("/<int:id>/liked_music", methods=["GET"])
def liked_music(user_id: int):
    user = User.query.get_or_404(id)
    result = []
    for music_item in user.liked_music:
        result.append(music_item.serialize())
    return jsonify(result)


@bp.route("/<int:id>/liking_users", methods=["GET"])
def liking_users(source_track_id: int):
    sm = Source.query.get_or_404(id)
    result = []
    for user in sm.liking_users:
        result.append(user.serialize())
    return jsonify(result)
